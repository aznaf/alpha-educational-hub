<?php include("session.php"); ?>
<?php include("header.php"); ?>

<div class="azr40"></div>

<div class="container w3-center">
<h6 class="primary-font w3-blue w3-round-large w3-card w3-padding">Dashboard</h6>
<div class="azr20"></div>
<a href="01_form.php" class="w3-button w3-black w3-round-large">Applications Form</a>
<a href="01_form_list.php" class="w3-button w3-black w3-round-large">Applications List</a>
<div class="azr40"></div>
</div>

