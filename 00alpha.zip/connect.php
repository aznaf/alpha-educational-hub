<?php
//database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "alpha";
// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo"database connection error<br>";
  die("Connection failed: " . $conn->connect_error);
}




// email configuration
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
	$mail = new PHPMailer(true);
	$mail->SMTPDebug = 0;									
	$mail->isSMTP();											
	$mail->Host	 = 'smtp-relay.sendinblue.com;';					
	$mail->SMTPAuth = true;							
	$mail->Username = 'alphaeducationhub076@gmail.com';				
	$mail->Password = 'xsmtpsib-21e14205907ce9beade9ebd14dbffc8b2e3bcdb11a1b3e4e1c4089d210a93b11-8hZgf3bCdsXqIWcv';						
	$mail->SMTPSecure = 'tls';							
	$mail->Port	 = 587;
  $mail->isHTML(true);
	$mail->setFrom('notify@alphaedutech.com', 'Alpha Edutech');


?>