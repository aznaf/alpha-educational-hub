<?php include("session.php") ?>
<?php include("header.php");?>

<div class="container w3-center">
<div class="azr10"></div>
<img src="assets/img/logo.png" alt="Alpha The Education Hub" class=" img-fluid w3-card w3-padding w3-round-large" width="20%" >
<h1 class="primary-font">Alpha</h1>
<p class="secondary-font">The Educational Hub</p>
</div>


<div class="container secondary-font ">
<form action="01_form_submit.php" method="post" enctype="multipart/form-data">

<label class="w3-text-black w3-left">Student Photo </label>
<input name="photo" id="photo" type="file"  accept="image/*;capture=camera" class="w3-input w3-border w3-border-black w3-text-blue "  placeholder="Student Photo" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Student Name </label>
<input type="text" name="s_name" id="s_name"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>

<label  >Gender</label><br>
    <input class="w3-radio" style="accent-color: #0096FF;" type="radio" name="gender" id="gender" value="male" checked >
    <label>Male</label>
    <input class="w3-radio" style="accent-color: #0096FF;" type="radio" name="gender"  id="gender" value="female">
    <label>Female</label>
    <div class="azr20"></div>


<label class="w3-text-black w3-left">Category </label>
<input type="text" name="category" id="category"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Aadhaar Number </label>
<input type="number" name="adhar" id="adhar"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>



<label class="w3-text-black w3-left">Father's Name </label>
<input type="text" name="f_name" id="f_name"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Father's Occupation </label>
<input type="text" name="f_occupation" id="f_occupation"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Mohter's Name </label>
<input type="text" name="m_name" id="m_name"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Mother's Occupation </label>
<input type="text" name="m_occupation" id="m_occupation"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Address </label>
<input type="textarea" name="address" id="address"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Pincode </label>
<input type="number" name="pincode" id="pincode"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Guardian (Phone Number) </label>
<input type="number" name="g_phone" id="g_phone"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Student Phone</label>
<input type="text" name="s_phone" id="s_phone"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>

<label class="w3-text-black w3-left">Email</label>
<br>
<small class="w3-text-blue w3-tiny">This Email will be used for all further communications</small>
<input type="email" name="email" id="email"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>

<label class="w3-text-black w3-left">Class &  Board</label>
<input type="text" name="class" id="class"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>

<label class="w3-text-black w3-left">School/College</label>
<input type="text" name="school" id="school"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Date From</label>
<input type="date" name="date_from" id="date_from"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Date To</label>
<input type="date" name="date_to" id="date_to"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>


<label class="w3-text-black w3-left">Date Of Birth</label>
<input type="date" name="dob" id="dob"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>



<label class="w3-text-black w3-left">Subject</label>
<input type="text" name="subject" id="subject"  class="w3-input w3-border w3-border-black w3-round w3-text-blue" required>
<div class="azr20"></div>

<a href='dashboard.php' class='w3-button w3-black w3-hover-blue'>Back To Dashboard</a>
<input type="submit" value="Submit Application" name="submit"  id="submit" class="w3-right w3-button w3-black w3-hover-blue" required>

</form>

<div class="azr40"></div>
</div>

