<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "<script type='text/javascript'>alert('Username or Password Cannot Be Empty!')</script>";
}
else
{
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];

// Establishing Connection with Server by passing server_name, user_id and password as a parameter
include("connect.php");
// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);

$username = mysqli_real_escape_string($conn,$username);
$password = mysqli_real_escape_string($conn,$password);

// echo $username;
//   echo $password;
// Selecting Database
// SQL query to fetch information of registerd users and finds user match.
$query = mysqli_query($conn,"select * from login where password='$password' AND username='$username'");
$rows = mysqli_num_rows($query);
  // echo $rows;
if ($rows == 1) {
$data = mysqli_fetch_array($query);
$_SESSION['login_user']=$username; // Initializing Session
$_SESSION['id']= $data['id'];

header("location:dashboard.php"); // Redirecting To Other Page
} else {
$error = "<script type ='text/javascript'>alert(' Invalid Username or Password   ');</script>";
}
mysqli_close($conn); // Closing Connection
}
}
?>
