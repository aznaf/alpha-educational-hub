<?php
include('header.php'); // Includes header Script
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: dashboard.php");

}
?>
<div class="azr10"></div>
<div class="container w3-center">
<div class="azr10"></div>
<img src="assets/img/logo.png" alt="Alpha The Education Hub" class=" img-fluid w3-card w3-black w3-padding w3-round-large" width="20%" >
<h1 class="primary-font w3-text-blue">ALPHA</h1>
<p class="secondary-font">The Educational Hub</p>
<small class="secondary-font w3-border  ">Known For The Knowledge</small>
</div>
<div class="azr40"></div>
  <form action="#" method="post" class="w3-padding">
  <input class="w3-input w3-border w3-border-black w3-round secondary-font" id="username" name="username" placeholder="Username" type="text">
    <div class="azr20"></div>
  <input class="w3-input w3-border w3-border-black w3-round secondary-font" id="password" name="password" placeholder="Password" type="password">
    <div class="azr20"></div>
  <button class=" w3-button w3-right w3-black w3-round secondary-font" name="submit" type="submit" >Login</button><br><br>    
    
  <span><?php echo $error; ?>
     <div class="azr40"></div><div class="azr40"></div> <div class="azr40"></div><div class="azr40"></div> <div class="azr40"></div><div class="azr40"></div>
  </form>
 

  
  </body>
  
  </html>

  