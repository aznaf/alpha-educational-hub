-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2023 at 02:42 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alpha`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `category` varchar(300) NOT NULL,
  `adhar` varchar(25) NOT NULL,
  `f_name` varchar(300) NOT NULL,
  `f_occupation` varchar(300) NOT NULL,
  `m_name` varchar(300) NOT NULL,
  `m_occupation` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `pincode` varchar(300) NOT NULL,
  `g_phone` varchar(300) NOT NULL,
  `s_phone` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `class` varchar(300) NOT NULL,
  `school` varchar(300) NOT NULL,
  `date_from` varchar(300) NOT NULL,
  `date_to` varchar(300) NOT NULL,
  `dob` varchar(300) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `photo` varchar(300) NOT NULL,
  `date` varchar(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `gender`, `category`, `adhar`, `f_name`, `f_occupation`, `m_name`, `m_occupation`, `address`, `pincode`, `g_phone`, `s_phone`, `email`, `class`, `school`, `date_from`, `date_to`, `dob`, `subject`, `photo`, `date`, `timestamp`) VALUES
(1, '222', 'male', '5222', '232432545454', 'Nnxnndjdj', 'Hjdjfjfh', 'Lakshmi', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2022-12-23', '2022-12-23', '2022-12-17', 'azr', 'uploads/08553783810_63b0538a803f6/dog.jpg', '2022-12-31', '2022-12-31 15:21:46'),
(2, '222', 'female', '5222', '32424234324324', 'Nnxnndjdj', 'afdasfa', 'Lakshmi', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2022-12-22', '2022-12-09', '2022-12-16', 'test subject ', 'uploads/08553783810_63b068994e711/dog2.jpg', '2022-12-31', '2022-12-31 16:51:37'),
(3, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11cb06d11a/dog1.png', '2023-01-01', '2023-01-01 05:40:00'),
(4, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11ce494b98/dog1.png', '2023-01-01', '2023-01-01 05:40:52'),
(5, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11cf69bd59/dog1.png', '2023-01-01', '2023-01-01 05:41:10'),
(6, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11d0b7f629/dog1.png', '2023-01-01', '2023-01-01 05:41:31'),
(7, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11d1e02fc5/dog1.png', '2023-01-01', '2023-01-01 05:41:50'),
(8, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11d263232a/dog1.png', '2023-01-01', '2023-01-01 05:41:58'),
(9, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11d2c75bd2/dog1.png', '2023-01-01', '2023-01-01 05:42:04'),
(10, '222', 'female', '5222', '2343257690', 'azrf', 'Hjdjfjfh', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-14', '2023-01-11', '2023-01-11', 'azr', 'uploads/08553783810_63b11d3a69995/dog1.png', '2023-01-01', '2023-01-01 05:42:18'),
(11, '222', 'male', '5222', '789687926456', 'Nnxnndjdj', 'afdasfa', 'Hfhfhf', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-06', '2023-01-05', '2023-01-20', 'subjecskfalsdjfl', 'uploads/08553783810_63b11da46dfc4/02.jpg', '2023-01-01', '2023-01-01 05:44:04'),
(12, '222', 'male', '5222', '32567890232', 'azrf', 'Hjdjfjfh', 'Lakshmi', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-12', '2023-01-18', '2023-01-17', 'azr', 'uploads/08553783810_63b11f2316d75/dog.jpg', '2023-01-01', '2023-01-01 05:50:27'),
(13, '222', 'male', '5222', '32567890232', 'azrf', 'Hjdjfjfh', 'Lakshmi', 'Bbbbbb', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', '', '5555', 'CMR Institute of Technology', '2023-01-12', '2023-01-18', '2023-01-17', 'azr', 'uploads/08553783810_63b11fa8ae1a7/dog.jpg', '2023-01-01', '2023-01-01 05:52:40'),
(14, '222', 'female', '5222', '7879845413345', 'Nnxnndjdj', 'afdasfa', 'Lakshmi', 'Teacher ', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-12', '2023-01-06', '2023-01-05', 'azr', 'uploads/08553783810_63b28885b686e/01.jpg', '2023-01-02', '2023-01-02 07:32:21'),
(15, '222', 'male', '5222', '7897465461', '54545', '4114', '141414', '141414', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '8553783810', '8553783810', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-19', '2023-01-26', '2023-01-19', 'English', 'uploads/8553783810_63b2d344753d1/03.jpg', '2023-01-02', '2023-01-02 12:51:16'),
(16, '222', 'female', '5222', '9845029852', 'alkjdf', 'adf', 'asfd', 'adsf', 'adf', '562125', '08553783810', '9876543210', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-02', '2023-01-04', '2023-01-18', 'Full Stack Development', 'uploads/08553783810_63b2d4247ef0c/02.jpg', '2023-01-02', '2023-01-02 12:55:00'),
(17, '222', 'male', '5222', '9845098450', 'azrf', 'Hjdjfjfh', 'Xjdifjfufj', 'Bbbbbb', '#17, 9th Cross, Vinobhanagar,', '560045', '08553783810', '09876543210', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-11', '2023-01-12', '2023-01-20', 'Full Stack Development', 'uploads/08553783810_63b2d541d0922/01.jpg', '2023-01-02', '2023-01-02 12:59:45'),
(18, '222', 'male', '5222', '9845098450', 'azrf', 'Hjdjfjfh', 'Xjdifjfufj', 'Bbbbbb', '#17, 9th Cross, Vinobhanagar,', '560045', '08553783810', '09876543210', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-11', '2023-01-12', '2023-01-20', 'Full Stack Development', 'uploads/08553783810_63b2d615010c3/01.jpg', '2023-01-02', '2023-01-02 13:03:17'),
(19, '222', 'male', '5222', '9845098450', 'azrf', 'Hjdjfjfh', 'Xjdifjfufj', 'Bbbbbb', '#17, 9th Cross, Vinobhanagar,', '560045', '08553783810', '09876543210', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-11', '2023-01-12', '2023-01-20', 'Full Stack Development', 'uploads/08553783810_63b2d639c8e53/01.jpg', '2023-01-02', '2023-01-02 13:03:53'),
(20, '222', 'male', '5222', '9845098450', 'azrf', 'Hjdjfjfh', 'Xjdifjfufj', 'Bbbbbb', '#17, 9th Cross, Vinobhanagar,', '560045', '08553783810', '09876543210', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-11', '2023-01-12', '2023-01-20', 'Full Stack Development', 'uploads/08553783810_63b2d68d9f257/01.jpg', '2023-01-02', '2023-01-02 13:05:17'),
(21, '222', 'male', '5222', '9845098450', 'Ghdhfh', 'Hjdjfjfh', 'Lakshmi', 'Teacher ', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '562125', '08553783810', '08553783810', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-11', '2023-01-18', '2023-01-18', 'test subject ', 'uploads/08553783810_63b2d765ce884/02.jpg', '2023-01-02', '2023-01-02 13:08:53'),
(22, '222', 'female', 'afasfsadf', '32432432', '424332432', '234324', '23432432', '234234', 'Dommasandra Bus Stop, Sarjapur Road Bangalore', '560045', '09876543210', '08553783810', 'aznafat@gmail.com', '5555', 'CMR Institute of Technology', '2023-01-19', '2023-01-05', '2023-01-12', 'Full Stack Development', 'uploads/09876543210_63b2de84477af/02.jpg', '2023-01-02', '2023-01-02 13:39:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
