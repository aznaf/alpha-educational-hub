<?php 
include("header.php");
include("session.php");
include("connect.php");
echo "<center>";
if(isset($_POST['submit']))
{

$required = array('s_name','gender','category','adhar','f_name','f_occupation','m_name',
                'm_occupation','address','pincode','g_phone','s_phone','email','class','school','date_from','date_to','dob','subject');


// Loop over field names, make sure each one exists and is not empty
$error = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}




if ($error) {
    echo " Incomplete Application";
  } 
  else 
  {
    $s_name = $_POST['s_name'];
    $gender = $_POST['gender'];
    $category = $_POST['category'];
    $adhar = $_POST['adhar'];
    $f_name = $_POST['f_name'];
    $f_occupation = $_POST['f_occupation'];
    $m_name = $_POST['m_name'];
    $m_occupation = $_POST['m_occupation'];
    $address = $_POST['address'];
    $pincode = $_POST['pincode'];
    $g_phone = $_POST['g_phone'];
    $s_phone = $_POST['s_phone'];
    $email = $_POST['email'];
    $class = $_POST['class'];
    $school = $_POST['school'];
    $date_from = $_POST['date_from'];
    $date_to = $_POST['date_to'];
    $dob = $_POST['dob'];
    $subject = $_POST['subject'];


    
    //setting timezone 
    date_default_timezone_set("Asia/Kolkata");
    //date
    $date = date("Y-m-d");
    $year = date("Y");
    $month = date("m");
    $day = date("d");
  
        $target_dir = "uploads/".$g_phone."_".uniqid()."/";
        mkdir($target_dir);
    $target_file = $target_dir . basename($_FILES["photo"]["name"]);
      $uploadOk = 1;
  
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      $location="uploads/noimage.jpg";
  
  
  if(isset($_POST["submit"])) {
    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["photo"]["tmp_name"]);
    if($check !== false) {
      
      $uploadOk = 1;
    } else {
      echo " File is not an image ❌ <br><br> ";
      
      $uploadOk = 0;
    }
  }
  
  // Check if file already exists
  if (file_exists($target_file)) {
    echo " Oops Image Already Exists ❌<br><br> ";
    
    $uploadOk = 0;
  }
  
  // Check file size
  //if ($_FILES["photo"]["size"] > 5000000) {
   // echo "<p class='quick w3-center  secondary-font w3-center'>Sorry, your file is large than 5MB. ❌</p>";
  //  $uploadOk = 0;
  //}
   
  
    
  // Allow certain file formats
  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
    echo " Only Images Allowed (jpg and png) ❌ <br><br> ";
    
    $uploadOk = 0;
  }
  
  // Check if $uploadOk is set to 0 by an error
  if ($uploadOk == 0) {
    echo " Oops Some Error Occurred  ❌ <br><br>";
    
  // if everything is ok, try to upload file
  } else {
  //compress
  
    
    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                  
      
                  $photo_name  = $_FILES['photo']['name'];
                  $location=$target_dir.$photo_name;
                  #$source = \Tinify\fromFile($location);
                  #$source->toFile($location);
      
      echo " Photo Uploaded Successfully ✔ <br><br> ";
      
    } else {
      echo " Oops Error While Uploading ❌ <br><br  ";
      
    }
  }
      $sql =" INSERT INTO `students`
      (`name`, `gender`, `category`, `adhar`, `f_name`, `f_occupation`, `m_name`, `m_occupation`, `address`, `pincode`, `g_phone`, `s_phone`,`email`, `class`, `school`, `date_from`, `date_to`, `dob`, `subject`, `date`,`photo`) 
      VALUES
      ('".$s_name."','".$gender."','".$category."','".$adhar."','".$f_name."','".$f_occupation."','".$m_name."','".$m_occupation."','".$address."','".$pincode."','".$g_phone."','".$s_phone."','".$email."','".$class."','".$school."','".$date_from."','".$date_to."','".$dob."','".$subject."','".$date."','".$location."')
    ";
  if($conn->query($sql)=== TRUE){
    echo " Application Submitted Successfully ✔  <br><br>";
    
    // Content

    $mail->AddAddress($email,'Alpha EduTech');
    $mail->isHTML(true);                       // Set email format to HTML
    $mail->Subject = 'Your Enrollment In '.$subject.' Is Successful';
    $mail->Body    = '
    Student name: '.$s_name.'<br>
    Aadhaar number : '.$adhar.'<br>
    class : '.$class.'<br>
    Subject : '.$subject.'<br>
    Duration : '.$date_from.'-'.$date_to.'<br><br><br>
    Thanks & Regards <br>
    Apha Edutech
    ';
    $mail->AltBody = 'Student name: '.$s_name.'<br>
    Aadhaar number : '.$adhar.'<br>
    class : '.$class.'<br>
    Subject : '.$subject.'<br>
    Duration : '.$date_from.' to '.$date_to.'<br><br><br>
    Thanks & Regards <br>
    Apha Edutech
    ';

    $mail->send();


    echo " Email Notification Has Been Sent ✔ <br><br> ";

    
    
    
    // header( "refresh:2;url=dashboard.php" );
    
    

    


  }
   }  
   echo "
   <p class='w3-red'>Do Not Refresh This Page...redirects in 5sec</p>
   <a href='dashboard.php' class='w3-button w3-black w3-hover-blue'>Back to Dashboard</a><br><br><br><br></center>";
   header( "refresh:5;url=dashboard.php" );
  }
  

