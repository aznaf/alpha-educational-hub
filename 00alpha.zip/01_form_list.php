<?php 
include("connect.php");
include("header.php");
?>
     
     
<script>  
$(document).ready(function(){
  $("#search").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#reports tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
  
</script>
<div class="azr20"></div>
<div class="w3-black">
  <h5 class="secondary-font bold w3-text-white w3-center">Report List </h5>
</div>
<div class="w3-padding w3-round-large w3-white" style="position: fixed; top: 2;width:400px;overflow: hidden;">
  <table class="w3-table">
      <tr>
    <td>
     <input type="text" class="w3-input secondary-font w3-border w3-border-gray w3-small" id="search" placeholder="search"> 
    </td>
    <td><button class="w3-button secondary-font w3-black w3-text-white w3-small " onClick="window.location.reload();">Refresh Page</button></td>
    <td><a href ="dashboard.php" class="w3-button secondary-font w3-black w3-text-white w3-small">Dashboard</a></td>
    </tr>
  </table>
</div>

<div class="azr40"></div>
<div class="azr40"></div>

<table class="w3-table-all  secondary-font w3-small" >
    <tr class="w3-text-white w3-black bold">
        <td>#</td>
        <td>Phone</td>
        <td>Name</td>
        <td>Action</td>
    </tr>
 <tbody id="reports">
<?php
$sql = "SELECT * from students order by id desc";
$result = mysqli_query($conn,$sql);


while($row = mysqli_fetch_array($result)) {	
    $id = $row['id'];
    $phone = $row['g_phone'];
   
 
     echo "  
     <tr>
        <td class='bold w3-small'>{$row['id']}</td>
        <td class='bold w3-small'>{$row['g_phone']}</td>
        <td class='bold w3-small'>{$row['name']}</td>
        <td><button onclick=\"document.getElementById('{$row['id']}').style.display='block'\" class='w3-button w3-black  w3-text-white'>View</button></td>
    </tr>

<!-- The Modal -->
<div id='{$row['id']}' class='w3-modal'>
  <div class='w3-modal-content'>
    <div class='w3-container w3-padding secondary-font '>
      <span onclick=\"document.getElementById('{$row['id']}').style.display='none'\"
      class='w3-button w3-black w3-display-topright'>✖</span>
      
        <center><b class='w3-text-white w3-black w3-padding'>Application Details </b><br><hr></center>
        <center><img src='{$row['photo']}' width='20%' class='img-fluid w3-center w3-border w3-round-large w3-border-black'></center>
        <br><br>
        <b class='w3-text-black'>Date To :  </b>{$row['date_to']}<br><hr>
        <b class='w3-text-black'>ID : </b>{$row['id']}<br><hr>
        <b class='w3-text-black'>Name : </b>{$row['name']}<br><hr>
        <b class='w3-text-black'>Gender : </b>{$row['gender']}<br><hr>
        <b class='w3-text-black'>Date of Birth:  </b>{$row['dob']}<br><hr>
        <b class='w3-text-black'>Category : </b>{$row['category']}<br><hr>
        <b class='w3-text-black'>Aadhaar : </b>{$row['adhar']}<br><hr>
        <b class='w3-text-black'>Father's Name : </b>{$row['f_name']}<br><hr>
        <b class='w3-text-black'>Father's Occupation : </b>{$row['f_occupation']}<br><hr>
        <b class='w3-text-black'>Mother's Name : </b>{$row['m_name']}<br><hr>
        <b class='w3-text-black'>Mother's Occupation : </b>{$row['m_occupation']}<br><hr>
        <b class='w3-text-black'>Address :  </b>{$row['address']}<br><hr>
        <b class='w3-text-black'>Pincode :  </b>{$row['pincode']}<br><hr>
        <b class='w3-text-black'>Guardian Phone :  </b>{$row['g_phone']}<br><hr>
        <b class='w3-text-black'>Student Phone :  </b>{$row['s_phone']}<br><hr>
        <b class='w3-text-black'>Class :  </b>{$row['class']}<br><hr>
        <b class='w3-text-black'>School :  </b>{$row['school']}<br><hr>
        <b class='w3-text-black'>Date From :  </b>{$row['date_from']}<br><hr>
        <b class='w3-text-black'>Subject  :  </b>{$row['subject']}<br><hr>
        <b class='w3-text-black'>Application Date  :  </b>{$row['date']}<br><hr>
        <b class='w3-text-black'>Timestamp  :  </b>{$row['timestamp']}<br><hr>
  
     
        
        
    </div>
  </div>
</div>


";
}
 
?>

</tbody>
</table>

